#
# Copyright (C) 2023-2026 The LineageOS Project
#
# SPDX-License-Identifier: Apache-2.0
#

PRODUCT_MAKEFILES := \
    $(LOCAL_PATH)/lineage_bahamut.mk

COMMON_LUNCH_CHOICES := \
    lineage_bahamut-user \
    lineage_bahamut-userdebug \
    lineage_bahamut-eng
