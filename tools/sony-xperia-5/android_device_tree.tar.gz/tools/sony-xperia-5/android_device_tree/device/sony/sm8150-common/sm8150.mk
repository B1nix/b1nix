#
# Copyright (C) 2023-2026 The LineageOS Project
#
# SPDX-License-Identifier: Apache-2.0
#

LOCAL_PATH := device/sony/sm8150-common

# Inherit proprietary common vendor files
$(call inherit-product, vendor/sony/sm8150-common/sm8150-common-vendor.mk)

# Overlays
PRODUCT_PACKAGES += \
    SonyKumanoFrameworksResCommon \
    SonyKumanoSystemUIResCommon \
    SonyKumanoSettingsResCommon \
    SonyKumanoTelephonyResCommon \
    CarrierConfigResCommon

# Rootdir scripts and fstab
PRODUCT_COPY_FILES += \
    $(LOCAL_PATH)/rootdir/etc/fstab.qcom:$(TARGET_COPY_OUT_VENDOR)/etc/fstab.qcom \
    $(LOCAL_PATH)/rootdir/etc/fstab.qcom:$(TARGET_COPY_OUT_RAMDISK)/system/etc/fstab.qcom \
    $(LOCAL_PATH)/rootdir/etc/init.sony.rc:$(TARGET_COPY_OUT_ODM)/etc/init/init.sony.rc \
    $(LOCAL_PATH)/rootdir/bin/init.qcom.msim.sh:$(TARGET_COPY_OUT_ODM)/bin/init.qcom.msim.sh

# Audio configuration
PRODUCT_COPY_FILES += \
    $(call find-copy-subdir-files,*,$(LOCAL_PATH)/audio,$(TARGET_COPY_OUT_VENDOR)/etc)

# GPS configuration
PRODUCT_COPY_FILES += \
    $(LOCAL_PATH)/gps/gps.conf:$(TARGET_COPY_OUT_VENDOR)/etc/gps.conf

# Wi-Fi configuration
PRODUCT_COPY_FILES += \
    $(call find-copy-subdir-files,*,$(LOCAL_PATH)/wifi,$(TARGET_COPY_OUT_VENDOR)/etc/wifi)

# A/B support
AB_OTA_UPDATER := true
AB_OTA_PARTITIONS += \
    boot \
    dtbo \
    odm \
    product \
    system \
    system_ext \
    vbmeta \
    vendor

# Audio props
PRODUCT_PROPERTY_OVERRIDES += \
    aaudio.hw_burst_min_usec=2000 \
    aaudio.mmap_exclusive_policy=2 \
    aaudio.mmap_policy=2 \
    audio.deep_buffer.media=true \
    audio.offload.video=true \
    persist.vendor.audio.fluence.voicecall=true \
    persist.vendor.audio.fluence.voicerec=true \
    persist.vendor.audio.speaker.prot.enable=true \
    persist.vendor.audio.voicecall.speaker.stereo=true \
    ro.audio.monitorRotation=true \
    vendor.audio.feature.a2dp_offload.enable=true \
    vendor.audio.feature.fluence.enable=true \
    vendor.audio.feature.spkr_prot.enable=true \
    vendor.audio.offload.buffer.size.kb=32 \
    vendor.audio.offload.gapless.enabled=true

# Display & Graphics props
PRODUCT_PROPERTY_OVERRIDES += \
    ro.surface_flinger.supports_background_blur=1 \
    ro.surface_flinger.force_hwc_copy_for_virtual_displays=true \
    ro.surface_flinger.has_HDR_display=true \
    ro.surface_flinger.has_wide_color_display=true \
    ro.surface_flinger.use_color_management=true \
    ro.hardware.egl=adreno \
    ro.hardware.vulkan=adreno \
    ro.opengles.version=196610

# Radio / Telephony
PRODUCT_PROPERTY_OVERRIDES += \
    ro.telephony.default_network=9,9 \
    persist.vendor.radio.enableadvancedscan=true \
    persist.vendor.radio.custom_ecc=1 \
    persist.vendor.radio.procedure_bytes=SKIP \
    persist.vendor.radio.rat_on=combine \
    persist.vendor.radio.sib16_support=1 \
    persist.vendor.radio.vdp_on_ims_cap=1

# USB
PRODUCT_PROPERTY_OVERRIDES += \
    vendor.usb.use_ffs_mtp=1 \
    vendor.usb.use_gadget_hal=1
