#
# Copyright (C) 2023-2026 The LineageOS Project
#
# SPDX-License-Identifier: Apache-2.0
#

LOCAL_PATH := $(call my-dir)

ifeq ($(TARGET_SOC),sm8150)
include $(call all-makefiles-under,$(LOCAL_PATH))
endif
