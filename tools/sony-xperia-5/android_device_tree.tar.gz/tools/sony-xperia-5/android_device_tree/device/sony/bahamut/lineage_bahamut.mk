#
# Copyright (C) 2023-2026 The LineageOS Project
#
# SPDX-License-Identifier: Apache-2.0
#

# Inherit from those products. Most specific first.
$(call inherit-product, $(SRC_TARGET_DIR)/product/core_64_bit_only.mk)
$(call inherit-product, $(SRC_TARGET_DIR)/product/full_base_telephony.mk)

# Inherit from sm8150-common
$(call inherit-product, device/sony/sm8150-common/sm8150.mk)

# Inherit from device-specific configuration
$(call inherit-product, device/sony/bahamut/device.mk)

# Inherit some common Lineage stuff
$(call inherit-product, vendor/lineage/config/common_full_phone.mk)

# Device identifier
PRODUCT_NAME := lineage_bahamut
PRODUCT_DEVICE := bahamut
PRODUCT_BRAND := Sony
PRODUCT_MODEL := Xperia 5
PRODUCT_MANUFACTURER := Sony
PRODUCT_GMS_CLIENTID_BASE := android-sonymobile

# Build fingerprint
PRODUCT_BUILD_PROP_OVERRIDES += \
    TARGET_DEVICE=J9210 \
    PRODUCT_NAME=J9210 \
    PRIVATE_BUILD_DESC="J9210-user 11 55.2.A.4.332 055002A004033203408384484 release-keys"

BUILD_FINGERPRINT := Sony/J9210/J9210:11/55.2.A.4.332/055002A004033203408384484:user/release-keys
