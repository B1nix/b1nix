#
# Copyright (C) 2023-2026 The LineageOS Project
#
# SPDX-License-Identifier: Apache-2.0
#

DEVICE_PATH := device/sony/bahamut

# Inherit from sm8150-common
include device/sony/sm8150-common/BoardConfigCommon.mk

# Board
BOARD_VENDOR := sony
TARGET_BOOTLOADER_BOARD_NAME := msmnile
TARGET_SCREEN_DENSITY := 420

# Inherit proprietary vendor BoardConfig
include vendor/sony/bahamut/BoardConfigVendor.mk
