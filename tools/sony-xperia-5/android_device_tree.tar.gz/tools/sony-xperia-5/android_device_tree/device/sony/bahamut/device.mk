#
# Copyright (C) 2023-2026 The LineageOS Project
#
# SPDX-License-Identifier: Apache-2.0
#

# Inherit proprietary vendor files
$(call inherit-product, vendor/sony/bahamut/bahamut-vendor.mk)

# Overlays
PRODUCT_PACKAGES += \
    SonyBahamutFrameworksRes \
    SonyBahamutSystemUIRes \
    ApertureResBahamut \
    SettingsResBahamut

# Keylayout
PRODUCT_COPY_FILES += \
    $(LOCAL_PATH)/keylayout/gpio-keys.kl:$(TARGET_COPY_OUT_VENDOR)/usr/keylayout/gpio-keys.kl

# Shipping API
PRODUCT_SHIPPING_API_LEVEL := 28

# Device properties
PRODUCT_PRODUCT_PROPERTIES += \
    ro.product.device=bahamut \
    ro.product.model=Xperia 5
